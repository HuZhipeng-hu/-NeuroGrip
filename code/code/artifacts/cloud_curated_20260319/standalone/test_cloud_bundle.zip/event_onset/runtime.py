"""Runtime state machine and feature helpers for multi-class event-onset control."""

from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass
from typing import Any, Callable, Deque, Optional, Sequence

import numpy as np

from event_onset.config import EventDataConfig, EventInferenceConfig, EventRuntimeBehaviorConfig
from shared.event_labels import public_event_label
from shared.gestures import GestureType
from shared.preprocessing import PreprocessPipeline


@dataclass
class RuntimeDecision:
    state: GestureType
    changed: bool
    emitted_label: int
    voted_label: int
    emitted_class_name: str


@dataclass
class ControllerStep:
    sample_index: int
    now_ms: float
    energy: float
    predicted_label: int
    confidence: float
    decision: RuntimeDecision


class EventRuntimeStateMachine:
    """Event-onset runtime controller with vote, latching and idle release for N action labels."""

    def __init__(
        self,
        inference_config: EventInferenceConfig,
        runtime_config: EventRuntimeBehaviorConfig,
        *,
        low_energy_threshold: float,
        class_names: Sequence[str],
        label_to_state: dict[int, GestureType],
    ):
        if not class_names:
            raise ValueError("class_names must not be empty")
        if 0 not in label_to_state:
            raise ValueError("label_to_state must contain label 0 (CONTINUE/RELAX).")

        self.inference_config = inference_config
        self.runtime_config = runtime_config
        self.low_energy_threshold = float(low_energy_threshold)
        self.class_names = [str(name).strip().upper() for name in class_names]
        self.label_to_state = dict(label_to_state)
        self.action_labels = {idx for idx in range(1, len(self.class_names))}
        self.release_mode = str(getattr(runtime_config, "release_mode", "idle_or_command")).strip().lower()
        if self.release_mode not in {"idle_or_command", "command_only"}:
            raise ValueError(
                f"Unsupported release_mode={self.release_mode!r}. "
                "Expected one of: idle_or_command, command_only."
            )

        self.current_label = 0
        self.current_state = self.label_to_state.get(0, GestureType.RELAX)
        self._vote_window: Deque[int] = deque(maxlen=max(1, int(inference_config.vote_window)))
        self._idle_since_ms: Optional[float] = None
        self._last_transition_ms: float = -1e9

    def _class_name(self, label: int) -> str:
        if 0 <= int(label) < len(self.class_names):
            return public_event_label(self.class_names[int(label)])
        return f"CLASS_{int(label)}"

    def _class_threshold(self, label: int) -> float:
        base = float(self.inference_config.confidence_threshold)
        class_name = self._class_name(label)
        overrides = self.inference_config.per_class_confidence_thresholds or {}
        return float(overrides.get(class_name, base))

    def _vote(self) -> int:
        if not self._vote_window:
            return 0
        counts = Counter(self._vote_window)
        label, count = counts.most_common(1)[0]
        if count >= int(self.inference_config.vote_min_count):
            return int(label)
        return 0

    def _accept_action_event(
        self,
        predicted_label: int,
        confidence: float,
        *,
        current_state_confidence: float,
        top2_confidence: float,
        now_ms: float,
        gate_confidence: float | None = None,
        command_confidence: float | None = None,
    ) -> bool:
        if predicted_label not in self.action_labels:
            return False

        if gate_confidence is not None:
            gate_threshold = self.inference_config.gate_confidence_threshold
            if gate_threshold is None:
                gate_threshold = float(self.inference_config.confidence_threshold)
            if float(gate_confidence) < float(gate_threshold):
                return False

        switching = self.current_label in self.action_labels and predicted_label != self.current_label
        threshold = self._class_threshold(predicted_label)
        if self.inference_config.command_confidence_threshold is not None:
            threshold = max(float(threshold), float(self.inference_config.command_confidence_threshold))
        if switching:
            threshold += float(self.inference_config.switch_confidence_boost)
        decision_confidence = float(command_confidence) if command_confidence is not None else float(confidence)
        if decision_confidence < threshold:
            return False

        margin_to_top2 = float(decision_confidence) - float(top2_confidence)
        if margin_to_top2 < float(self.inference_config.activation_margin_threshold):
            return False

        if switching:
            if (now_ms - self._last_transition_ms) < float(self.runtime_config.post_transition_lock_ms):
                return False
            margin_to_current = float(decision_confidence) - float(current_state_confidence)
            if margin_to_current < float(self.inference_config.switch_margin_threshold):
                return False
        return True

    def update(
        self,
        predicted_label: int,
        confidence: float,
        energy: float,
        now_ms: float,
        *,
        current_state_confidence: float = 0.0,
        top2_confidence: float = 0.0,
        gate_confidence: float | None = None,
        command_confidence: float | None = None,
    ) -> RuntimeDecision:
        now_ms = float(now_ms)
        active_event = self._accept_action_event(
            int(predicted_label),
            float(confidence),
            current_state_confidence=float(current_state_confidence),
            top2_confidence=float(top2_confidence),
            now_ms=now_ms,
            gate_confidence=gate_confidence,
            command_confidence=command_confidence,
        )
        if active_event:
            last_active = next(
                (label for label in reversed(self._vote_window) if label in self.action_labels),
                None,
            )
            if last_active is not None and int(last_active) != int(predicted_label):
                self._vote_window.clear()
            self._vote_window.append(int(predicted_label))
            voted_label = self._vote()
            self._idle_since_ms = None
            if voted_label in self.action_labels and (
                now_ms - self._last_transition_ms
            ) >= float(self.runtime_config.min_transition_gap_ms):
                self.current_label = int(voted_label)
                target_state = self.label_to_state.get(self.current_label, GestureType.RELAX)
                changed = target_state != self.current_state
                self.current_state = target_state
                self._last_transition_ms = now_ms
                return RuntimeDecision(
                    state=self.current_state,
                    changed=changed,
                    emitted_label=self.current_label,
                    voted_label=int(voted_label),
                    emitted_class_name=self._class_name(self.current_label),
                )
            return RuntimeDecision(
                state=self.current_state,
                changed=False,
                emitted_label=0,
                voted_label=int(voted_label),
                emitted_class_name=self._class_name(0),
            )

        self._vote_window.append(0)
        if energy <= self.low_energy_threshold:
            if self._idle_since_ms is None:
                self._idle_since_ms = now_ms
        else:
            self._idle_since_ms = None

        if (
            self.release_mode != "command_only"
            and self._idle_since_ms is not None
            and (now_ms - self._idle_since_ms) >= float(self.runtime_config.idle_release_hold_ms)
        ):
            self.current_label = 0
            target_state = self.label_to_state.get(0, GestureType.RELAX)
            changed = self.current_state != target_state
            self.current_state = target_state
            self._last_transition_ms = now_ms if changed else self._last_transition_ms
            return RuntimeDecision(
                state=self.current_state,
                changed=changed,
                emitted_label=0,
                voted_label=0,
                emitted_class_name=self._class_name(0),
            )

        return RuntimeDecision(
            state=self.current_state,
            changed=False,
            emitted_label=0,
            voted_label=0,
            emitted_class_name=self._class_name(0),
        )


class EventFeatureExtractor:
    """Build aligned EMG and IMU runtime inputs from causal windows."""

    def __init__(self, data_config: EventDataConfig):
        self.data_config = data_config
        self._stft_pipeline = PreprocessPipeline(
            {
                "sampling_rate": data_config.device_sampling_rate_hz,
                "num_channels": 8,
                "target_length": data_config.context_samples,
                "segment_length": data_config.context_samples,
                "segment_stride": data_config.window_step_samples,
                "stft_window": data_config.feature.emg_stft_window,
                "stft_hop": data_config.feature.emg_stft_hop,
                "n_fft": data_config.feature.emg_n_fft,
                "freq_bins_out": data_config.feature.emg_freq_bins,
                "normalize": "log",
                "clip_min": 0.0,
                "clip_max": 10.0,
                "dual_branch": {"enabled": False},
            }
        )

    def _resample_imu(self, imu_window: np.ndarray) -> np.ndarray:
        target_steps = int(self.data_config.feature.imu_resample_steps)
        if imu_window.shape[0] == target_steps:
            resampled = imu_window
        else:
            src = np.linspace(0.0, 1.0, imu_window.shape[0], dtype=np.float32)
            dst = np.linspace(0.0, 1.0, target_steps, dtype=np.float32)
            resampled = np.empty((target_steps, imu_window.shape[1]), dtype=np.float32)
            for channel_idx in range(imu_window.shape[1]):
                resampled[:, channel_idx] = np.interp(dst, src, imu_window[:, channel_idx]).astype(np.float32)
        centered = resampled - np.mean(resampled, axis=0, keepdims=True)
        std = np.std(centered, axis=0, keepdims=True)
        std = np.where(std < 1e-6, 1.0, std)
        return (centered / std).T.astype(np.float32)

    def build_inputs(self, matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray, float]:
        emg_window = matrix[:, :8]
        imu_window = matrix[:, 8:14]
        energy = float(np.mean(np.abs(emg_window)))
        emg_feature = self._stft_pipeline.process_window(emg_window)
        imu_feature = self._resample_imu(imu_window)
        return emg_feature, imu_feature, energy


def build_runtime_inputs(matrix: np.ndarray, data_config: EventDataConfig) -> tuple[np.ndarray, np.ndarray, float]:
    extractor = EventFeatureExtractor(data_config)
    return extractor.build_inputs(matrix)


class EventOnsetController:
    """Reusable event-onset runtime controller for live and replay flows."""

    def __init__(
        self,
        *,
        data_config: EventDataConfig,
        inference_config: EventInferenceConfig,
        runtime_config: EventRuntimeBehaviorConfig,
        class_names: Sequence[str],
        label_to_state: dict[int, GestureType],
        predict_proba: Callable[[np.ndarray, np.ndarray], np.ndarray],
        predict_detail: Callable[[np.ndarray, np.ndarray], Any] | None = None,
        actuator=None,
    ):
        self.data_config = data_config
        self.predict_proba = predict_proba
        self.predict_detail = predict_detail
        self.actuator = actuator
        self.extractor = EventFeatureExtractor(data_config)
        self.state_machine = EventRuntimeStateMachine(
            inference_config=inference_config,
            runtime_config=runtime_config,
            low_energy_threshold=float(runtime_config.low_energy_release_threshold or data_config.quality_filter.energy_min),
            class_names=class_names,
            label_to_state=label_to_state,
        )
        self._buffer: Deque[np.ndarray] = deque(maxlen=int(data_config.context_samples))
        self._processed_samples = 0
        self._next_infer_sample = int(data_config.context_samples)

    @property
    def current_state(self) -> GestureType:
        return self.state_machine.current_state

    def ingest_rows(self, rows: np.ndarray) -> list[ControllerStep]:
        if rows.size == 0:
            return []
        if rows.ndim != 2 or rows.shape[1] < 14:
            raise ValueError(f"Expected input rows shaped (N, >=14), got {rows.shape}")
        steps: list[ControllerStep] = []
        for row in np.asarray(rows[:, :14], dtype=np.float32):
            self._buffer.append(row.copy())
            self._processed_samples += 1
            if len(self._buffer) >= int(self.data_config.context_samples) and self._processed_samples >= self._next_infer_sample:
                step = self._process_current()
                if step is not None:
                    steps.append(step)
                self._next_infer_sample += int(self.data_config.window_step_samples)
        return steps

    def _process_current(self) -> ControllerStep | None:
        context = int(self.data_config.context_samples)
        if len(self._buffer) < context:
            return None
        matrix = np.asarray(self._buffer, dtype=np.float32)[-context:]
        emg_feature, imu_feature, energy = self.extractor.build_inputs(matrix)
        detail = self.predict_detail(emg_feature, imu_feature) if self.predict_detail is not None else None
        probs = (
            np.asarray(detail.public_probs, dtype=np.float32)
            if detail is not None
            else np.asarray(self.predict_proba(emg_feature, imu_feature), dtype=np.float32)
        )
        gate_confidence = None
        command_confidence = None
        if detail is not None and getattr(detail, "gate_probs", None) is not None and getattr(detail, "command_probs", None) is not None:
            gate_probs = np.asarray(detail.gate_probs, dtype=np.float32)
            command_probs = np.asarray(detail.command_probs, dtype=np.float32)
            gate_confidence = float(gate_probs[1]) if gate_probs.shape[0] > 1 else None
            if gate_confidence is None:
                predicted_label = 0
                confidence = float(probs[0]) if probs.size else 0.0
                top2_confidence = 0.0
            else:
                gate_threshold = self.state_machine.inference_config.gate_confidence_threshold
                if gate_threshold is None:
                    gate_threshold = float(self.state_machine.inference_config.confidence_threshold)
                if float(gate_confidence) < float(gate_threshold):
                    predicted_label = 0
                    confidence = float(probs[0]) if probs.size else 0.0
                    top2_confidence = 0.0
                else:
                    predicted_label = 1 + int(np.argmax(command_probs))
                    command_confidence = float(np.max(command_probs))
                    confidence = float(command_confidence)
                    sorted_command = np.sort(command_probs)[::-1]
                    top2_confidence = float(sorted_command[1]) if sorted_command.size > 1 else 0.0
        else:
            predicted_label = int(np.argmax(probs))
            confidence = float(np.max(probs))
            sorted_probs = np.sort(probs)[::-1]
            top2_confidence = float(sorted_probs[1]) if sorted_probs.size > 1 else 0.0
        current_label = int(self.state_machine.current_label)
        if command_confidence is not None and detail is not None and getattr(detail, "command_probs", None) is not None:
            command_probs = np.asarray(detail.command_probs, dtype=np.float32)
            command_index = current_label - 1
            current_state_confidence = float(command_probs[command_index]) if command_index >= 0 and command_index < command_probs.shape[0] else 0.0
        else:
            current_state_confidence = float(probs[current_label]) if current_label < probs.shape[0] else 0.0
        now_ms = float(self._processed_samples) * 1000.0 / float(self.data_config.device_sampling_rate_hz)
        decision = self.state_machine.update(
            predicted_label,
            confidence,
            energy,
            now_ms,
            current_state_confidence=current_state_confidence,
            top2_confidence=top2_confidence,
            gate_confidence=gate_confidence,
            command_confidence=command_confidence,
        )
        if decision.changed and self.actuator is not None:
            self.actuator.execute_gesture(decision.state)
        return ControllerStep(
            sample_index=self._processed_samples,
            now_ms=now_ms,
            energy=energy,
            predicted_label=predicted_label,
            confidence=confidence,
            decision=decision,
        )
